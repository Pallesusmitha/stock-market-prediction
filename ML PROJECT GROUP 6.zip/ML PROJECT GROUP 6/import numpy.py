import numpy
arr=numpy.array((11,34,56,7))
print(arr)